
<a href="bpp07.input.score.php"> Fyll i po�ng</a> | <a href="bpp07.input.players.php"> Fyll i spelare</a> | <a href="bpp07.input.games.php"> Fyll i spel</a> |=| <a href="bpp07.results.php?sortby=tag"> Resultat efter tag</a> | <a href="bpp07.results.php?sortby=namn"> namn</a> | <a href="bpp07.results.php?sortby=spel"> spelnamn</a> |=| <a href="bpp07.ranking.php">Rankingen</a><br><br>

<hr>

